--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acquisti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acquisti (
    id integer NOT NULL,
    utente character varying,
    scarpa integer,
    nome character varying,
    prezzo bigint,
    taglia integer,
    immagine character varying,
    completato boolean
);


ALTER TABLE public.acquisti OWNER TO postgres;

--
-- Name: acquisti_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acquisti_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.acquisti_id OWNER TO postgres;

--
-- Name: aste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aste (
    id integer NOT NULL,
    scarpa integer NOT NULL,
    acquirente character varying,
    prezzo_partenza integer NOT NULL,
    prezzo_corrente integer NOT NULL,
    fine bigint NOT NULL,
    nome character varying,
    taglia integer,
    immagine character varying
);


ALTER TABLE public.aste OWNER TO postgres;

--
-- Name: aste_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aste_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aste_id OWNER TO postgres;

--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id integer NOT NULL,
    scarpa integer NOT NULL,
    img text NOT NULL
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id OWNER TO postgres;

--
-- Name: ordini; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ordini (
    id integer NOT NULL,
    utente character varying,
    scarpa integer,
    nome character varying,
    prezzo bigint,
    taglia integer,
    immagine character varying
);


ALTER TABLE public.ordini OWNER TO postgres;

--
-- Name: ordini_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordini_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ordini_id OWNER TO postgres;

--
-- Name: recensioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni (
    id integer NOT NULL,
    titolo character varying NOT NULL,
    rating smallint NOT NULL,
    autore character varying NOT NULL,
    scarpa integer NOT NULL
);


ALTER TABLE public.recensioni OWNER TO postgres;

--
-- Name: recensioni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recensioni_id OWNER TO postgres;

--
-- Name: scarpe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scarpe (
    id integer NOT NULL,
    nome character varying NOT NULL,
    tipo character varying NOT NULL,
    prezzo_orig double precision NOT NULL,
    descrizione character varying,
    anno_uscita integer NOT NULL,
    marca character varying NOT NULL,
    proprietario character varying NOT NULL,
    tipo_annuncio character varying NOT NULL,
    prezzo_attuale double precision NOT NULL,
    colore character varying,
    taglia integer NOT NULL,
    venduta boolean DEFAULT false NOT NULL
);


ALTER TABLE public.scarpe OWNER TO postgres;

--
-- Name: scarpe_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scarpe_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scarpe_id OWNER TO postgres;

--
-- Name: utenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utenti (
    id character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    email character varying NOT NULL,
    telefono bigint,
    tipologia character varying NOT NULL,
    password character varying NOT NULL,
    bannato boolean NOT NULL
);


ALTER TABLE public.utenti OWNER TO postgres;

--
-- Data for Name: acquisti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acquisti (id, utente, scarpa, nome, prezzo, taglia, immagine, completato) FROM stdin;
\.
COPY public.acquisti (id, utente, scarpa, nome, prezzo, taglia, immagine, completato) FROM '$$PATH$$/4886.dat';

--
-- Data for Name: aste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aste (id, scarpa, acquirente, prezzo_partenza, prezzo_corrente, fine, nome, taglia, immagine) FROM stdin;
\.
COPY public.aste (id, scarpa, acquirente, prezzo_partenza, prezzo_corrente, fine, nome, taglia, immagine) FROM '$$PATH$$/4888.dat';

--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, scarpa, img) FROM stdin;
\.
COPY public.images (id, scarpa, img) FROM '$$PATH$$/4890.dat';

--
-- Data for Name: ordini; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ordini (id, utente, scarpa, nome, prezzo, taglia, immagine) FROM stdin;
\.
COPY public.ordini (id, utente, scarpa, nome, prezzo, taglia, immagine) FROM '$$PATH$$/4892.dat';

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni (id, titolo, rating, autore, scarpa) FROM stdin;
\.
COPY public.recensioni (id, titolo, rating, autore, scarpa) FROM '$$PATH$$/4894.dat';

--
-- Data for Name: scarpe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scarpe (id, nome, tipo, prezzo_orig, descrizione, anno_uscita, marca, proprietario, tipo_annuncio, prezzo_attuale, colore, taglia, venduta) FROM stdin;
\.
COPY public.scarpe (id, nome, tipo, prezzo_orig, descrizione, anno_uscita, marca, proprietario, tipo_annuncio, prezzo_attuale, colore, taglia, venduta) FROM '$$PATH$$/4896.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utenti (id, nome, cognome, email, telefono, tipologia, password, bannato) FROM stdin;
\.
COPY public.utenti (id, nome, cognome, email, telefono, tipologia, password, bannato) FROM '$$PATH$$/4898.dat';

--
-- Name: acquisti_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acquisti_id', 124, true);


--
-- Name: aste_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aste_id', 40, true);


--
-- Name: images_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id', 90, true);


--
-- Name: ordini_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordini_id', 31, true);


--
-- Name: recensioni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensioni_id', 14, true);


--
-- Name: scarpe_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scarpe_id', 66, true);


--
-- Name: acquisti acquisti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquisti
    ADD CONSTRAINT acquisti_pk PRIMARY KEY (id);


--
-- Name: aste aste_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_pk PRIMARY KEY (id);


--
-- Name: images images_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pk PRIMARY KEY (id);


--
-- Name: ordini ordini_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordini
    ADD CONSTRAINT ordini_pk PRIMARY KEY (id);


--
-- Name: recensioni recensioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_pk PRIMARY KEY (id);


--
-- Name: scarpe scarpe_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scarpe
    ADD CONSTRAINT scarpe_pk PRIMARY KEY (id);


--
-- Name: utenti utenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pk PRIMARY KEY (id);


--
-- Name: acquisti acquisti_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquisti
    ADD CONSTRAINT acquisti_fk FOREIGN KEY (utente) REFERENCES public.utenti(id) ON DELETE CASCADE;


--
-- Name: acquisti acquisti_scarpe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acquisti
    ADD CONSTRAINT acquisti_scarpe_fk FOREIGN KEY (scarpa) REFERENCES public.scarpe(id) ON DELETE CASCADE;


--
-- Name: aste aste_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_fk_1 FOREIGN KEY (scarpa) REFERENCES public.scarpe(id) ON DELETE CASCADE;


--
-- Name: aste aste_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_fk_2 FOREIGN KEY (acquirente) REFERENCES public.utenti(id) ON DELETE SET NULL;


--
-- Name: images images_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_fk FOREIGN KEY (scarpa) REFERENCES public.scarpe(id) ON DELETE CASCADE;


--
-- Name: ordini ordini_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordini
    ADD CONSTRAINT ordini_fk FOREIGN KEY (utente) REFERENCES public.utenti(id) ON DELETE CASCADE;


--
-- Name: ordini ordini_scarpe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordini
    ADD CONSTRAINT ordini_scarpe_fk FOREIGN KEY (scarpa) REFERENCES public.scarpe(id) ON DELETE CASCADE;


--
-- Name: recensioni recensioni_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_fk FOREIGN KEY (scarpa) REFERENCES public.scarpe(id) ON DELETE CASCADE;


--
-- Name: recensioni recensioni_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_fk_1 FOREIGN KEY (autore) REFERENCES public.utenti(id) ON DELETE CASCADE;


--
-- Name: scarpe scarpe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scarpe
    ADD CONSTRAINT scarpe_fk FOREIGN KEY (proprietario) REFERENCES public.utenti(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO pg_database_owner;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

